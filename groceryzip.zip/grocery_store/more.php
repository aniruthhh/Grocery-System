<html>
    <head>
        <title>GROCERY HUB</title>
        <link rel="stylesheet" href="designn.css">
        
    </head>
    <body>
    <div class="top_body">
    <div class="top_part">
        <div class="top_left">
        <ul>
            <li> <a href="main.php"><img src="logo.png" alt="grocey" width="70px" height="70px"></a></li>
            <li><input type="text" placeholder="Search.."></li>
        </ul>
        </div>
    <div class="top_right">
        <ul>
            <li><a href="login.php"><img src="login.png" alt="grocey" width="50px" height="50px"></a></li>
            <li><a href="cart.php"><img src="shopping-basket.png" alt="grocey" width="50px" height="50px"></a></li>
        </ul>
    </div>
</div>
    <div class="bottom_part">
        <ul>
            <li>Categoreies
            <div class="dropdown">
                <ul>
                    <li><a href="exotic_fruits.php">fruits</a></li>
                    <li><a href="vegies.php">vegies</a></li>
                    <li><a href="snacks.php">snacks</a></li>

                </ul>
            </div>
        </li>
        <li><a href="exotic_fruits.php">Exotic Fruits</a></li>
        <li><a href="dailyneeds.php">Daily Needs</a></li>
        <li><a href="vegies.php">Fresh Vegies</a></li>
        <li><a href="more.php">More About Us</a></li>
        <li><a href="contactus.php">Contact Us</a></li>
        </ul>

    
</div>
</div>
<div class="more">
    <h2>More About Us</h2>
    <p>Did you ever imagine that the freshest of fruits and vegetables, top-quality pulses and food grains, dairy products, and hundreds of branded items could be handpicked and delivered to your home, all at the click of a button? In today's fast-paced world, bigbasket.com, India's pioneering online grocery store, continues to bring a staggering array of over 40,000 products from more than 1,000 brands to the doorsteps of over 10 million satisfied customers. From essential household cleaning products to the latest beauty and makeup trends, bigbasket remains your one-stop shop for daily needs.</p>
    <br><p>In these times, we've eliminated the stress associated with shopping for daily essentials. You can now effortlessly order all your household products and groceries online. Plus, the added convenience of finding all your requirements at a single source, coupled with substantial savings, demonstrates that bigbasket, India's largest online supermarket, has transformed the way we shop for groceries. Online grocery shopping has become second nature. And when it comes to freshness, whether it's fruits and vegetables or dairy and meat, we've got you covered! Easily obtain fresh eggs, meat, fish, and more with just a few clicks.</p>
    <br><p>We now serve <b>300+ cities and towns</b> across India and ensure swift delivery times, guaranteeing that all your groceries, snacks and branded foods reach you on time.</p>
    <br><p><b>Slotted Delivery:</b> Choose the most convenient delivery slot to receive your groceries, ranging from early morning delivery for early birds to late-night delivery for those on the night shift. bigbasket caters to every schedule.</p>
    <br><p><b>Instant delivery from bbnow:</b> In response to the ever-increasing demand for convenience, bbnow by bigbasket offers lightning-fast grocery delivery, ensuring that your essentials are at your doorstep within 15-30 minutes. Our quick delivery service has revolutionized the way you shop for groceries. Choose from 5000+ grocery essentials. bbnow is available only in select cities.
    </p>
    <br><p>Whether it's a last-minute dinner party or you simply need something urgently, we've got you covered. This service exemplifies our commitment to providing you with not just the widest range of products but also the fastest and most efficient shopping experience, making bigbasket.com the go-to destination for all your immediate grocery needs.</p>
    <hr>
    
    </div>
    <footer>
        <div class="social-media">
            <a href="#"><img src="facebook.png" alt="Facebook" height="50px" width="50px"></a>
            <a href="#"><img src="twitter.png" alt="X" height="50px" width="50px"></a>
            <a href="#"><img src="instagram.png" alt="Instagram" height="50px" width="50px"></a>
        </div>
        <div class="newsletter">
            <h3>Subscribe to Our Newsletter</h3>
            <form>
                <input type="email" placeholder="Enter your email">
                <button type="submit">Subscribe</button>
            </form>
        </div>
    </footer>
      <script src="animation.js">


      </script>
</body>
</html>