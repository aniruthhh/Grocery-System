<?php
session_start();

?>

<html>

<head>
    <title>EXOTIC FRUITS</title>
    <link rel="stylesheet" href="designn.css">

</head>

<body>
    <div class="top_body">
        <div class="top_part">
            <div class="top_left">
                <ul>
                    <li> <a href="main.php"><img src="logo.png" alt="grocey" width="70px" height="70px"></a></li>
                    <li><input type="text" placeholder="Search.."></li>
                </ul>
            </div>
            <div class="top_right">
                <ul>
                    <li><a href="login.php"><img src="login.png" alt="grocey" width="50px" height="50px"></a></li>
                    <li><a href="cart.php"><img src="shopping-basket.png" alt="grocey" width="50px" height="50px"></a></li>
                </ul>
            </div>
        </div>
        <div class="bottom_part">
            <ul>
                <li>Categoreies
                    <div class="dropdown">
                        <ul>
                            <li><a href="exotic_fruits.php">fruits</a></li>
                            <li><a href="vegies.php">vegies</a></li>
                            <li><a href="snacks.php">snacks</a></li>

                        </ul>
                    </div>
                </li>
                <li><a href="exotic_fruits.php">Exotic Fruits</a></li>
                <li><a href="dailyneeds.php">Daily Needs</a></li>
                <li><a href="vegies.php">Fresh Vegies</a></li>
                <li><a href="more.php">More About Us</a></li>
                <li><a href="contactus.php">Contact Us</a></li>
            </ul>


        </div>
    </div>
    <br>
    <h3 class="titleee">Daily Needs</h3>
    <div class="dailyneeds-container">
        <div class="daily_need">
            <img src="potato.jpg" alt="daily_needs Name">
            <h4>Potato</h4>
            <p>50/kg</p>
            <div class="quantity">
                <form action="dailyneeds.php" method="POST">
                    <input type="text" value="1" min="1" step="1" name="potatovalue">
                    <span>kg</span><br>
                    <button class="add-to-cart" name="potato">Add to Cart</button>
                </form>
            </div>

        </div>
        <div class="daily_need">
            <img src="eggs.jpg" alt="daily_needs Name">
            <h4>Eggs</h4>
            <p>5/pc</p>
            <div class="quantity">
                <form action="dailyneeds.php" method="POST">
                    <input type="text" value="1" min="1" step="1" name="eggsvalue">
                    <span>pc</span><br>
                    <button class="add-to-cart" name="eggs">Add to Cart</button>
                </form>
            </div>
        </div>
        <div class="daily_need">
            <img src="goodknight.jpg" alt="daily_needs Name">
            <h4>Good Knight</h4>
            <p>445/pc</p>
            <div class="quantity">
            <form action="dailyneeds.php" method="POST">
                    <input type="text" value="1" min="1" step="1" name="goodvalue">
                    <span>pc</span><br>
                    <button class="add-to-cart" name="goodknight">Add to Cart</button>
                </form>
                </div>
        </div>
        <div class="daily_need">
            <img src="coffeepowder.jpg" alt="daily_needs Name">
            <h4>Coffee Powder</h4>
            <p>100g</p>
            <div class="quantity">
                <form action="dailyneeds.php" method="POST">
                    <input type="text" value="1" min="1" step="1" name="coffeevalue">
                    <span>g</span><br>
                    <button class="add-to-cart" name="coffee">Add to Cart</button>
                </form>
                </div>
        </div>
        <div class="daily_need">
            <img src="maggi.jpg" alt="daily_needs Name">
            <h4>Maggi</h4>
            <p>2 pack</p>
            <div class="quantity">
            <form action="dailyneeds.php" method="POST">
                    <input type="text" value="1" min="1" step="1" name="maggivalue">
                    <span>pack</span><br>
                    <button class="add-to-cart" name="maggi">Add to Cart</button>
                </form>
                </div>
        </div>
        <div class="daily_need">
            <img src="soap.jpg" alt="daily_needs Name">
            <h4>Soap</h4>
            <p>32/pc</p>
            <div class="quantity">
            <form action="dailyneeds.php" method="POST">
                    <input type="text" value="1" min="1" step="1" name="soapvalue">
                    <span>pc</span><br>
                    <button class="add-to-cart" name="soap">Add to Cart</button>
                </form>
                </div>
        </div>
        <div class="daily_need">
            <img src="surfexcel.jpg" alt="daily_needs Name">
            <h4>Surf Excel</h4>
            <p>60/L</p>
            <div class="quantity">
            <form action="dailyneeds.php" method="POST">
                    <input type="text" value="1" min="1" step="1" name="surfexvalue">
                    <span>pc</span><br>
                    <button class="add-to-cart" name="surfex">Add to Cart</button>
                </form>
                </div>
        </div>
        <div class="daily_need">
            <img src="toothpaste.jpg" alt="daily_needs Name">
            <h4>Tooth Paste</h4>
            <p>25/pc</p>
            <div class="quantity">
            <form action="dailyneeds.php" method="POST">
                    <input type="text" value="1" min="1" step="1" name="toothvalue">
                    <span>pc</span><br>
                    <button class="add-to-cart" name="tooth">Add to Cart</button>
                </form>
                </div>
        </div>
        <div class="daily_need">
            <img src="dettol.jpg" alt="daily_needs Name">
            <h4>Dettol</h4>
            <p>75/bottle</p>
            <div class="quantity">
            <form action="dailyneeds.php" method="POST">
                    <input type="text" value="1" min="1" step="1" name="dettolvalue">
                    <span>bottle</span><br>
                    <button class="add-to-cart" name="dettol">Add to Cart</button>
                </form>
            </div>
        </div>
        <div class="daily_need">
            <img src="dairywhit.jpg" alt="daily_needs Name">
            <h4>Dairy Whitener</h4>
            <p>50/packet</p>
            <div class="quantity">
            <form action="dailyneeds.php" method="POST">
                    <input type="text" value="1" min="1" step="1" name="dairyvalue">
                    <span>packet</span><br>
                    <button class="add-to-cart" name="dairy">Add to Cart</button>
                </form>
            </div>
        </div>
    </div>



    <footer>
        <div class="social-media">
            <a href="#"><img src="facebook.png" alt="Facebook" height="50px" width="50px"></a>
            <a href="#"><img src="twitter.png" alt="X" height="50px" width="50px"></a>
            <a href="#"><img src="instagram.png" alt="Instagram" height="50px" width="50px"></a>
        </div>
        <div class="newsletter">
            <h3>Subscribe to Our Newsletter</h3>
            <form>
                <input type="email" placeholder="Enter your email">
                <button type="submit">Subscribe</button>
            </form>
        </div>
    </footer>
</body>

</html>

<?php


if (isset($_POST["potato"])) {
    $quantity = $_POST["potatovalue"];
    $_SESSION["cart"]["potato"] = array("quantity" => $quantity, "price" => 50);
}

if (isset($_POST["eggs"])) {
    $quantity = $_POST["eggsvalue"];
    $_SESSION["cart"]["eggs"] = array("quantity" => $quantity, "price" => 5);
}
if (isset($_POST["goodknight"])) {
    $quantity = $_POST["goodvalue"];
    $_SESSION["cart"]["goodknight"] = array("quantity" => $quantity, "price" => 445);
}

if (isset($_POST["coffee"])) {
    $quantity = $_POST["coffeevalue"];
    $_SESSION["cart"]["coffee"] = array("quantity" => $quantity, "price" => 50);
}
if (isset($_POST["maggi"])) {
    $quantity = $_POST["maggivalue"];
    $_SESSION["cart"]["maggi"] = array("quantity" => $quantity, "price" => 50);
}
if (isset($_POST["soap"])) {
    $quantity = $_POST["soapvalue"];
    $_SESSION["cart"]["soap"] = array("quantity" => $quantity, "price" => 50);
}
if (isset($_POST["surfex"])) {
    $quantity = $_POST["surfexvalue"];
    $_SESSION["cart"]["surfex"] = array("quantity" => $quantity, "price" => 50);
}
if (isset($_POST["tooth"])) {
    $quantity = $_POST["toothvalue"];
    $_SESSION["cart"]["tooth"] = array("quantity" => $quantity, "price" => 50);
}
if (isset($_POST["dettol"])) {
    $quantity = $_POST["dettolvalue"];
    $_SESSION["cart"]["dettol"] = array("quantity" => $quantity, "price" => 50);
}
if (isset($_POST["dairy"])) {
    $quantity = $_POST["dairyvalue"];
    $_SESSION["cart"]["dairy"] = array("quantity" => $quantity, "price" => 50);
}

?>