<html>
    <head>
        <title>GROCERY HUB</title>
        <link rel="stylesheet" href="designn.css">
        
    </head>
    <body background="black">
    <div class="top_body">
    <div class="top_part">
        <div class="top_left">
        <ul>
            <li> <a href="main.php"><img src="logo.png" alt="grocey" width="70px" height="70px"></a></li>
            <li><input type="text" placeholder="Search.."></li>
        </ul>
        </div>
    <div class="top_right">
        <ul>
            <li><a href="login.php"><img src="login.png" alt="grocey" width="50px" height="50px"></a></li>
            <li><a href="cart.php"><img src="shopping-basket.png" alt="grocey" width="50px" height="50px"></a></li>
        </ul>
    </div>
</div>
    <div class="bottom_part">
        <ul>
            <li>Categoreies
            <div class="dropdown">
                <ul>
                    <li><a href="exotic_fruits.php">fruits</a></li>
                    <li><a href="vegies.php">vegies</a></li>
                    <li><a href="snacks.php">snacks</a></li>

                </ul>
            </div>
        </li>
        <li><a href="exotic_fruits.php">Exotic Fruits</a></li>
        <li><a href="dailyneeds.php">Daily Needs</a></li>
        <li><a href="vegies.php">Fresh Vegies</a></li>
        <li><a href="more.php">More About Us</a></li>
        <li><a href="contactus.php">Contact Us</a></li>
        </ul>

    
</div>
</div>
<br>

<div class="co">
    <h2 class="head">Checkout</h2>
    <form id="Checkout-form">
        <div class="form-group">
            <label>Name</label>
        <input type="text" class="form-control" id="checkout-name" name="name" placeholder="Name" required>
        <label>Email</label>
        <input type="text" class="form-control" id="checkout-email" name="email" placeholder="Email" required>
    </div>
    <div class="form-group">
        <label>Phone</label>
        <input type="tel" class="form-control" id="checkout-phone" name="phone" placeholder="Phone" required>
        <label>City</label>
        <input type="text" class="form-control" id="checkout-city" name="city" placeholder="City" required>
        <label>Address</label>
        <input type="text" class="form-control" id="checkout-address" name="address" placeholder="Address" required>
    </div>
    </form>
    <button type="submit" class="btn" id="checkout-btn" value="Checkout">Checkout</button>
    
</div>









<footer>
    <div class="social-media">
        <a href="#"><img src="facebook.png" alt="Facebook" height="50px" width="50px"></a>
        <a href="#"><img src="twitter.png" alt="X" height="50px" width="50px"></a>
        <a href="#"><img src="instagram.png" alt="Instagram" height="50px" width="50px"></a>
    </div>
    <div class="newsletter">
        <h3>Subscribe to Our Newsletter</h3>
        <form>
            <input type="email" placeholder="Enter your email">
            <button type="submit">Subscribe</button>
        </form>
    </div>
</footer>
  <script src="animation.js">


  </script>
</body>
</html>