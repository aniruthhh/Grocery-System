<?php
session_start();
?>

<html>

<head>
    <title>EXOTIC FRUITS</title>
    <link rel="stylesheet" href="designn.css">
    <style>
    table {
        width: 100%;
        border-collapse: collapse;
    }

    table, th, td {
        border: 1px solid #ddd;
    }

    th, td {
        padding: 8px;
        text-align: left;
    }

    th {
        background-color: #f2f2f2;
    }
</style>

</head>

<body>
    <div class="top_body">
        <div class="top_part">
            <div class="top_left">
                <ul>
                    <li> <a href="main.php"><img src="logo.png" alt="grocey" width="70px" height="70px"></a></li>
                    <li><input type="text" placeholder="Search.."></li>
                </ul>
            </div>
            <div class="top_right">
                <ul>
                    <li><a href="login.php"><img src="login.png" alt="grocey" width="50px" height="50px"></a></li>
                    <li><a href="cart.php"><img src="shopping-basket.png" alt="grocey" width="50px" height="50px"></a></li>
                </ul>
            </div>
        </div>
        <div class="bottom_part">
            <ul>
                <li>Categories
                    <div class="dropdown">
                        <ul>
                            <li><a href="exotic_fruits.php">fruits</a></li>
                            <li><a href="vegies.php">vegies</a></li>
                            <li><a href="snacks.php">snacks</a></li>

                        </ul>
                    </div>
                </li>
                <li><a href="exotic_fruits.php">Exotic Fruits</a></li>
                <li><a href="dailyneeds.php">Daily Needs</a></li>
                <li><a href="vegies.php">Fresh Vegies</a></li>
                <li><a href="more.php">More About Us</a></li>
                <li><a href="contactus.php">Contact Us</a></li>
            </ul>


        </div>
    </div>
    <div class="cart-container">
        <div class="container">
            <h2 class="textt">Your Cart</h2>
        </div>
    </div>
    <?php

    if (isset($_SESSION["cart"])) {
        echo "<h3>Items in your cart:</h3>";
        echo "
        <table> 
            <tr> 
                <th>Product name</th>
                <th>Quantity</th>
                <th>Price</th>
            </tr>
    ";

        $grandTotal = 0;

        foreach ($_SESSION["cart"] as $itemName => $data) {
            $price = isset($data["price"]) ? $data["price"] : 0;
            $quantity = isset($data["quantity"]) ? $data["quantity"] : 0;
            $totalPrice = $price * $quantity;
            $grandTotal += $totalPrice;
            echo "<tr> 
            <td>$itemName</td>
            <td>$quantity</td>
            <td>$totalPrice</td>
        </tr>";
        }
        echo "</table>";

        echo "<h3>Grand Total: ₹$grandTotal</h3>";
        $_SESSION["grandTotal"] = $grandTotal;

        echo "<form action='cart.php' method='POST'>
    <button type='submit' class='btn-submit' name='sub12'>checkout</button>
    </form> ";
    } else {
        echo "<h3>Your cart is empty</h3>";
    }
    ?>

    <a href="account.php"><button type="button" class="btn-submit">accounts</button></a>
<?php




if(isset($_POST['sub12'])){
if (isset($_SESSION["cart"])) {
    
    $username = $_COOKIE["user"];

    
    $orderId = uniqid();

    
    $grandTotal = $_SESSION["grandTotal"];

    
    $con = mysqli_connect("localhost", "root", "aravind", "groceryhub");

    
    if (!$con) {
        die("Connection failed: " . mysqli_connect_error());
    }

   
    $sql = "INSERT INTO orders (username, orderid, grandtotal) VALUES ('$username', '$orderId', '$grandTotal')";

    if (mysqli_query($con, $sql)) {
        echo "Order placed successfully.";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($con);
    }

    mysqli_close($con);

    
    unset($_SESSION["cart"]);

    
    header("Location: account.php");
    exit();
} else {
    echo "<h3>Your cart is empty</h3>";
}
}
?>





    </div>
    <br>
    <br>
    <footer>
        <div class="social-media">
            <a href="#"><img src="facebook.png" alt="Facebook" height="50px" width="50px"></a>
            <a href="#"><img src="twitter.png" alt="X" height="50px" width="50px"></a>
            <a href="#"><img src="instagram.png" alt="Instagram" height="50px" width="50px"></a>
        </div>
        <div class="newsletter">
            <h3>Subscribe to Our Newsletter</h3>
            <form>
                <input type="email" placeholder="Enter your email">
                <button type="submit">Subscribe</button>
            </form>
        </div>
    </footer>
    <script src="animation.js">


    </script>
</body>

</html>

