<html>
    <head>
        <title>GROCERY HUB</title>
        <link rel="stylesheet" href="designn.css">
        
    </head>
    <body>
    <div class="top_body">
    <div class="top_part">
        <div class="top_left">
        <ul>
            <li> <a href="main.php"><img src="logo.png" alt="grocey" width="70px" height="70px"></a></li>
            <li><input type="text" placeholder="Search.."></li>
        </ul>
        </div>
    <div class="top_right">
        <ul>
            <li><a href="login.php"><img src="login.png" alt="grocey" width="50px" height="50px"></a></li>
            <li><a href="cart.php"><img src="shopping-basket.png" alt="grocey" width="50px" height="50px"></a></li>
        </ul>
    </div>
</div>
    <div class="bottom_part">
        <ul>
            <li>Categoreies
            <div class="dropdown">
                <ul>
                    <li><a href="exotic_fruits.php">fruits</a></li>
                    <li><a href="vegies.php">vegies</a></li>
                    <li><a href="snacks.php">snacks</a></li>

                </ul>
            </div>
        </li>
        <li><a href="exotic_fruits.php">Exotic Fruits</a></li>
        <li><a href="dailyneeds.php">Daily Needs</a></li>
        <li><a href="vegies.php">Fresh Vegies</a></li>
        <li><a href="more.php">More About Us</a></li>
        <li><a href="contactus.php">Contact Us</a></li>
        </ul>

    
</div>
</div>
<br>
<div class="contact">
<h1 class="cont">CONTACT US</h1>
<p style="font-family: 'Times New Roman', Times, serif;font-size: medium;">Welcome to our contact us page! At GROCERY HUB, we value your feedback, inquiries, and suggestions. Whether you have a question about our products, need assistance with an order, or simply want to share your thoughts, we're here to help. Our dedicated customer support team is available to assist you with any queries you may have. Please feel free to reach out to us using the form below, and we'll get back to you as soon as possible. Thank you for choosing GROCERY HUB for your shopping needs. We look forward to hearing from you!

    Feel free to customize it to better fit the tone and branding of your e-commerce website</p>
<form>
    <h2 style="font-family: Georgia, 'Times New Roman', Times, serif;">TO KNOW MORE</h2>  
    <p>Email:groceryhub@support.com</p>
    <p>Contact:9999999999</p>    
    <label for="textarea">Any suggestions</label>
            <input type="text" id="text" required><br>
            
    <label for="message">Give us any reviews or concerns</label>
    <textarea id="message" name="message" rows="4" required></textarea>
</form>
</div>

      <footer>
        <div class="social-media">
            <a href="#"><img src="facebook.png" alt="Facebook" height="50px" width="50px"></a>
            <a href="#"><img src="twitter.png" alt="X" height="50px" width="50px"></a>
            <a href="#"><img src="instagram.png" alt="Instagram" height="50px" width="50px"></a>
        </div>
        <div class="newsletter">
            <h3>Subscribe to Our Newsletter</h3>
            <form>
                <input type="email" placeholder="Enter your email">
                <button type="submit">Subscribe</button>
            </form>
        </div>
    </footer>
      <script src="animation.js">


      </script>
</body>
</html>