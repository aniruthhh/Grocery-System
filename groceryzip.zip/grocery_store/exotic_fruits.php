<?php
session_start();
?>

<html>
    <head>
        <title>EXOTIC FRUITS</title>
        <link rel="stylesheet" href="designn.css">
        
    </head>
    <body>
    <div class="top_body">
    <div class="top_part">
        <div class="top_left">
        <ul>
            <li> <a href="main.php"><img src="logo.png" alt="grocey" width="70px" height="70px"></a></li>
            <li><input type="text" placeholder="Search.."></li>
        </ul>
        </div>
    <div class="top_right">
        <ul>
            <li><a href="login.php"><img src="login.png" alt="grocey" width="50px" height="50px"></a></li>
            <li><a href="cart.php"><img src="shopping-basket.png" alt="grocey" width="50px" height="50px"></a></li>
        </ul>
    </div>
</div>
    <div class="bottom_part">
        <ul>
            <li>Categoreies
            <div class="dropdown">
                <ul>
                    <li><a href="exotic_fruits.php">fruits</a></li>
                    <li><a href="vegies.php">vegies</a></li>
                    <li><a href="snacks.php">snacks</a></li>

                </ul>
            </div>
        </li>
        <li><a href="exotic_fruits.php">Exotic Fruits</a></li>
        <li><a href="dailyneeds.php">Daily Needs</a></li>
        <li><a href="vegies.php">Fresh Vegies</a></li>
        <li><a href="more.php">More About Us</a></li>
        <li><a href="contactus.php">Contact Us</a></li>
        </ul>

    
</div>
</div>
<br>
<h3 class="titleee">EXOTIC FRUITS COLLECTION</h3>
<div class="fruits-container">
    <div class="fruit">
        <img src="lychee.jpg" alt="Fruit Name">
        <h4>Lychee Fruit</h4>
        <p>160</p>
        <div class="quantity">
        <form action="exotic_fruits.php" method="POST">
                    <input type="text" value="1" min="1" step="1" name="lycheevalue">
                    <span>pc</span><br>
                    <button class="add-to-cart" name="lychee">Add to Cart</button>
                </form>
                </div>
    </div>
    <div class="fruit">
        <img src="durian.jpg" alt="Fruit Name">
        <h4>Durian Fruit</h4>
        <p>220</p>
        <div class="quantity">
        <form action="exotic_fruits.php" method="POST">
                    <input type="text" value="1" min="1" step="1" name="durianvalue">
                    <span>pc</span><br>
                    <button class="add-to-cart" name="durian">Add to Cart</button>
                </form>
                </div>
    </div>
    <div class="fruit">
        <img src="jackfruit.jpg" alt="Fruit Name">
        <h4>JackFruit</h4>
        <p>150</p>
        <div class="quantity">
        <form action="exotic_fruits.php" method="POST">
                    <input type="text" value="1" min="1" step="1" name="jackvalue">
                    <span>pc</span><br>
                    <button class="add-to-cart" name="jack">Add to Cart</button>
                </form>
                </div>
    </div>
    <div class="fruit">
        <img src="pomelo.jpg" alt="Fruit Name">
        <h4>Pomelo Fruit</h4>
        <p>250</p>
        <div class="quantity">
        <form action="exotic_fruits.php" method="POST">
                    <input type="text" value="1" min="1" step="1" name="pomelovalue">
                    <span>pc</span><br>
                    <button class="add-to-cart" name="pomelo">Add to Cart</button>
                </form>
                </div>
    </div>
    <div class="fruit">
        <img src="persimmon.jpg" alt="Fruit Name">
        <h4>Persimmon Fruit</h4>
        <p>350</p>
        <div class="quantity">
        <form action="exotic_fruits.php" method="POST">
                    <input type="text" value="1" min="1" step="1" name="persimmonvalue">
                    <span>pc</span><br>
                    <button class="add-to-cart" name="persimmon">Add to Cart</button>
                </form>
                </div>
    </div>
    <div class="fruit">
        <img src="passionfruit.jpg" alt="Fruit Name">
        <h4>Passion Fruit</h4>
        <p>285</p>
        <div class="quantity">
        <form action="exotic_fruits.php" method="POST">
                    <input type="text" value="1" min="1" step="1" name="passionvalue">
                    <span>pc</span><br>
                    <button class="add-to-cart" name="passion">Add to Cart</button>
                </form>
                </div>
    </div>
</div>



<footer>
    <div class="social-media">
        <a href="#"><img src="facebook.png" alt="Facebook" height="50px" width="50px"></a>
        <a href="#"><img src="twitter.png" alt="X" height="50px" width="50px"></a>
        <a href="#"><img src="instagram.png" alt="Instagram" height="50px" width="50px"></a>
    </div>
    <div class="newsletter">
        <h3>Subscribe to Our Newsletter</h3>
        <form>
            <input type="email" placeholder="Enter your email">
            <button type="submit">Subscribe</button>
        </form>
    </div>
</footer>
    </body>
</html>


<?php


if (isset($_POST["lychee"])) {
    $quantity = $_POST["lycheevalue"];
    $_SESSION["cart"]["lychee"] = array("quantity" => $quantity, "price" => 160);
}

if (isset($_POST["durian"])) {
    $quantity = $_POST["durianvalue"];
    $_SESSION["cart"]["durian"] = array("quantity" => $quantity, "price" => 220);
}
if (isset($_POST["jack"])) {
    $quantity = $_POST["jackvalue"];
    $_SESSION["cart"]["jack"] = array("quantity" => $quantity, "price" => 150);
}

if (isset($_POST["pomelo"])) {
    $quantity = $_POST["pomelovalue"];
    $_SESSION["cart"]["pomelo"] = array("quantity" => $quantity, "price" => 250);
}
if (isset($_POST["persimmon"])) {
    $quantity = $_POST["persimmonvalue"];
    $_SESSION["cart"]["persimmon"] = array("quantity" => $quantity, "price" => 350);
}
if (isset($_POST["passion"])) {
    $quantity = $_POST["passionvalue"];
    $_SESSION["cart"]["passion"] = array("quantity" => $quantity, "price" => 285);
}


?>
