<?php


$conn = mysqli_connect("localhost","root","aravind123","php_project")
          or die("couldnt connect to database");

?>