<?php
session_start();
?>

<html>

<head>
    <title>GROCERY HUB</title>
    <link rel="stylesheet" href="designn.css">

</head>

<body background="black">
    <div class="top_body">
        <div class="top_part">
            <div class="top_left">
                <ul>
                    <li> <a href="main.php"><img src="logo.png" alt="grocey" width="70px" height="70px"></a></li>
                    <li><input type="text" placeholder="Search.."></li>
                </ul>
            </div>
            <div class="top_right">
                <ul>
                    <li><a href="login.php"><img src="login.png" alt="grocey" width="50px" height="50px"></a></li>
                    <li><a href="cart.php"><img src="shopping-basket.png" alt="grocey" width="50px" height="50px"></a></li>
                </ul>
            </div>
        </div>
        <div class="bottom_part">
            <ul>
                <li>Categoreies
                    <div class="dropdown">
                        <ul>
                            <li><a href="exotic_fruits.php">fruits</a></li>
                            <li><a href="vegies.php">vegies</a></li>
                            <li><a href="snacks.php">snacks</a></li>

                        </ul>
                    </div>
                </li>
                <li><a href="exotic_fruits.php">Exotic Fruits</a></li>
                <li><a href="dailyneeds.php">Daily Needs</a></li>
                <li><a href="vegies.php">Fresh Vegies</a></li>
                <li><a href="more.php">More About Us</a></li>
                <li><a href="contactus.php">Contact Us</a></li>
            </ul>


        </div>
    </div>
    <div class="log">
        <h2 class="head">Register</h2>
        <form id="register-form" method="POST" action="register.php">
            <div class="form-group">
                <label>Name</label>
                <input type="text" class="form-control" id="register-name" name="name" placeholder="Name" required>
                <label>Email</label>
                <input type="text" class="form-control" id="register-login-email" name="email" placeholder="Email" required>
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" class="form-control" id="register-password" name="password" placeholder="Password" required>
                <label>Confirm Password</label>
                <input type="password" class="form-control" id="confirm-register-password" name="confirmpassword" placeholder="Confirm Password" required>
            </div>
            <button type="submit" class="btn-submit" name="submit">Submit</button>
        </form>
        <a href="login.php">Have an account!!Login Now</a>
    </div>


    <footer>
        <div class="social-media">
            <a href="#"><img src="facebook.png" alt="Facebook" height="50px" width="50px"></a>
            <a href="#"><img src="twitter.png" alt="X" height="50px" width="50px"></a>
            <a href="#"><img src="instagram.png" alt="Instagram" height="50px" width="50px"></a>
        </div>
        <div class="newsletter">
            <h3>Subscribe to Our Newsletter</h3>
            <form>
                <input type="email" placeholder="Enter your email">
                <button type="submit">Subscribe</button>
            </form>
        </div>
    </footer>
    <script src="animation.js">


    </script>
</body>

</html>

<?php
if (isset($_POST["submit"])) {
    $con = mysqli_connect("localhost", "root", "aravind");
    mysqli_query($con, "CREATE DATABASE IF NOT EXISTS groceryhub");
    mysqli_select_db($con, "groceryhub");

    $name = $_POST["name"];
    $email = $_POST["email"];
    $password = $_POST["password"];

    if ($password != $_POST["confirmpassword"]) {
        echo "<script>alert('Passwords do not match')</script>";
        exit();
    }

    $result = mysqli_query($con, "select * from users where email='$email'");
    $row = mysqli_fetch_array($result);

    if ($row) {
        echo "<script>alert('User already exists')</script>";
        exit();
    }

    mysqli_query($con, "insert into users(name,email,password) values('$name','$email','$password')");
    echo "<script>alert('Registered Successfully')</script>";
}
?>