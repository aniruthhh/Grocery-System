<?php
session_start();
?>

<html>
    <head>
        <title>GROCERY HUB</title>
        <link rel="stylesheet" href="designn.css">
        <style>
    table {
        width: 100%;
        border-collapse: collapse;
    }

    table, th, td {
        border: 1px solid #ddd;
    }

    th, td {
        padding: 8px;
        text-align: left;
    }

    th {
        background-color: #f2f2f2;
    }
</style>
        
    </head>
    <body background="black">
    <div class="top_body">
    <div class="top_part">
        <div class="top_left">
        <ul>
            <li> <a href="main.php"><img src="logo.png" alt="grocey" width="70px" height="70px"></a></li>
            <li><input type="text" placeholder="Search.."></li>
        </ul>
        </div>
    <div class="top_right">
        <ul>
            <li><a href="login.php"><img src="login.png" alt="grocey" width="50px" height="50px"></a></li>
            <li><a href="cart.php"><img src="shopping-basket.png" alt="grocey" width="50px" height="50px"></a></li>
        </ul>
    </div>
</div>
    <div class="bottom_part">
        <ul>
            <li>Categoreies
            <div class="dropdown">
                <ul>
                    <li><a href="exotic_fruits.php">fruits</a></li>
                    <li><a href="vegies.php">vegies</a></li>
                    <li><a href="snacks.php">snacks</a></li>

                </ul>
            </div>
        </li>
        <li><a href="exotic_fruits.php">Exotic Fruits</a></li>
        <li><a href="dailyneeds.php">Daily Needs</a></li>
        <li><a href="vegies.php">Fresh Vegies</a></li>
        <li><a href="more.php">More About Us</a></li>
        <li><a href="contactus.php">Contact Us</a></li>
        </ul>

    
</div>
</div>

<?php





$con = mysqli_connect("localhost", "root", "aravind", "groceryhub");


if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}


$username = $_COOKIE["user"];


$sql = "SELECT * FROM orders WHERE username = '$username'";
$result = mysqli_query($con, $sql);

if (mysqli_num_rows($result) > 0) {
    echo "<h3>Your Orders:</h3>";
    echo "<table >
            <tr>
                <th>Order ID</th>
                <th>Grand Total</th>
            </tr>";
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>";
        echo "<td>" . $row["orderid"] . "</td>";
        echo "<td>" . $row["grandtotal"] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<h3>No orders found</h3>";
}


?>

<footer>
    <div class="social-media">
        <a href="#"><img src="facebook.png" alt="Facebook" height="50px" width="50px"></a>
        <a href="#"><img src="twitter.png" alt="X" height="50px" width="50px"></a>
        <a href="#"><img src="instagram.png" alt="Instagram" height="50px" width="50px"></a>
    </div>
    <div class="newsletter">
        <h3>Subscribe to Our Newsletter</h3>
        <form>
            <input type="email" placeholder="Enter your email">
            <button type="submit">Subscribe</button>
        </form>
    </div>
</footer>
  <script src="animation.js">


  </script>
</body>
</html>