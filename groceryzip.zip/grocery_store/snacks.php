<?php
session_start();
?>

<html>
    <head>
        <title>Snacks</title>
        <link rel="stylesheet" href="designn.css">
        
    </head>
    <body>
    <div class="top_body">
    <div class="top_part">
        <div class="top_left">
        <ul>
            <li> <a href="main.php"><img src="logo.png" alt="grocey" width="70px" height="70px"></a></li>
            <li><input type="text" placeholder="Search.."></li>
        </ul>
        </div>
    <div class="top_right">
        <ul>
            <li><a href="login.php"><img src="login.png" alt="grocey" width="50px" height="50px"></a></li>
            <li><a href="cart.php"><img src="shopping-basket.png" alt="grocey" width="50px" height="50px"></a></li>
        </ul>
    </div>
</div>
    <div class="bottom_part">
        <ul>
            <li>Categoreies
            <div class="dropdown">
                <ul>
                    <li><a href="exotic_fruits.php">fruits</a></li>
                    <li><a href="vegies.php">vegies</a></li>
                    <li><a href="snacks.php">snacks</a></li>

                </ul>
            </div>
        </li>
        <li><a href="exotic_fruits.php">Exotic Fruits</a></li>
        <li><a href="dailyneeds.php">Daily Needs</a></li>
        <li><a href="vegies.php">Fresh Vegies</a></li>
        <li><a href="more.php">More About Us</a></li>
        <li><a href="contactus.php">Contact Us</a></li>
        </ul>

    
</div>
</div>
<br>
<h3 class="titleee">Snacks</h3>
<div class="snacks-container">
    <div class="snacks">
        <img src="bhujiasev.jpg" alt="Fruit Name">
        <h4>Bhujiya Sev</h4>
        <p>20/packet</p>
        <div class="quantity">
        <form action="snacks.php" method="POST">
                    <input type="text" value="1" min="1" step="1" name="bhujiavalue">
                    <span>packet</span><br>
                    <button class="add-to-cart" name="bhujia">Add to Cart</button>
                </form>
                </div>
    </div>
    <div class="snacks">
        <img src="bingo.jpg" alt="Fruit Name">
        <h4>Bingo</h4>
        <p>20/packet</p>
        <div class="quantity">
        <form action="snacks.php" method="POST">
                    <input type="text" value="1" min="1" step="1" name="bingovalue">
                    <span>packet</span><br>
                    <button class="add-to-cart" name="bingo">Add to Cart</button>
                </form>
                </div>
    </div>
    <div class="snacks">
        <img src="darkfantasy.jpg" alt="Fruit Name">
        <h4>Dark Fantasy</h4>
        <p>150/box</p>
        <div class="quantity">
        <form action="snacks.php" method="POST">
                    <input type="text" value="1" min="1" step="1" name="darkfvalue">
                    <span>box</span><br>
                    <button class="add-to-cart" name="darkf">Add to Cart</button>
                </form>
                </div>
    </div>
    <div class="snacks">
        <img src="lays.jpg" alt="Fruit Name">
        <h4>Lays</h4>
        <p>25/packet</p>
        <div class="quantity">
        <form action="snacks.php" method="POST">
                    <input type="text" value="1" min="1" step="1" name="laysvalue">
                    <span>packet</span><br>
                    <button class="add-to-cart" name="lays">Add to Cart</button>
                </form>
                </div>
    </div>
    <div class="snacks">
        <img src="jimjam.jpg" alt="Fruit Name">
        <h4>Jim Jam</h4>
        <p>35/packet</p>
        <div class="quantity">
        <form action="snacks.php" method="POST">
                    <input type="text" value="1" min="1" step="1" name="jimjamvalue">
                    <span>packet</span><br>
                    <button class="add-to-cart" name="jimjam">Add to Cart</button>
                </form>
                </div>
    </div>
    <div class="snacks">
        <img src="mariegold.jpg" alt="Fruit Name">
        <h4>Marie Gold</h4>
        <p>35/packet</p>
        <div class="quantity">
        <form action="snacks.php" method="POST">
                    <input type="text" value="1" min="1" step="1" name="marievalue">
                    <span>packet</span><br>
                    <button class="add-to-cart" name="marie">Add to Cart</button>
                </form>
                </div>
    </div>
</div>



<footer>
    <div class="social-media">
        <a href="#"><img src="facebook.png" alt="Facebook" height="50px" width="50px"></a>
        <a href="#"><img src="twitter.png" alt="X" height="50px" width="50px"></a>
        <a href="#"><img src="instagram.png" alt="Instagram" height="50px" width="50px"></a>
    </div>
    <div class="newsletter">
        <h3>Subscribe to Our Newsletter</h3>
        <form>
            <input type="email" placeholder="Enter your email">
            <button type="submit">Subscribe</button>
        </form>
    </div>
</footer>
    </body>
</html>

<?php


if (isset($_POST["bhujia"])) {
    $quantity = $_POST["bhujiavalue"];
    $_SESSION["cart"]["bhujia"] = array("quantity" => $quantity, "price" => 20);
}

if (isset($_POST["bingo"])) {
    $quantity = $_POST["bingovalue"];
    $_SESSION["cart"]["bingo"] = array("quantity" => $quantity, "price" => 20);
}
if (isset($_POST["darkf"])) {
    $quantity = $_POST["darkfvalue"];
    $_SESSION["cart"]["darkf"] = array("quantity" => $quantity, "price" => 150);
}

if (isset($_POST["lays"])) {
    $quantity = $_POST["laysvalue"];
    $_SESSION["cart"]["lays"] = array("quantity" => $quantity, "price" => 25);
}
if (isset($_POST["jimjam"])) {
    $quantity = $_POST["jimjamvalue"];
    $_SESSION["cart"]["jimjam"] = array("quantity" => $quantity, "price" => 35);
}
if (isset($_POST["marie"])) {
    $quantity = $_POST["marievalue"];
    $_SESSION["cart"]["marie"] = array("quantity" => $quantity, "price" => 35);
}


?>