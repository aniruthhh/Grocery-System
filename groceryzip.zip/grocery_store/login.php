

<html>

<head>
    <title>GROCERY HUB</title>
    <link rel="stylesheet" href="designn.css">

</head>

<body background="black">
    <div class="top_body">
        <div class="top_part">
            <div class="top_left">
                <ul>
                    <li> <a href="main.php"><img src="logo.png" alt="grocey" width="70px" height="70px"></a></li>
                    <li><input type="text" placeholder="Search.."></li>
                </ul>
            </div>
            <div class="top_right" id="top_right">
                <ul>
                    <li ><a href="login.php"><img src="login.png" alt="grocey" width="50px" height="50px"></a></li>
                    <li><a href="cart.php"><img src="shopping-basket.png" alt="grocey" width="50px" height="50px"></a></li>
                </ul>
            </div>
        </div>
        <div class="bottom_part">
            <ul>
                <li>Categoreies
                    <div class="dropdown">
                        <ul>
                            <li><a href="exotic_fruits.php">fruits</a></li>
                            <li><a href="vegies.php">vegies</a></li>
                            <li><a href="snacks.php">snacks</a></li>

                        </ul>
                    </div>
                </li>
                <li><a href="exotic_fruits.php">Exotic Fruits</a></li>
                <li><a href="dailyneeds.php">Daily Needs</a></li>
                <li><a href="vegies.php">Fresh Vegies</a></li>
                <li><a href="more.php">More About Us</a></li>
                <li><a href="contactus.php">Contact Us</a></li>
            </ul>


        </div>
    </div>
    <div class="log">
        <h2 class="head">LOGIN</h2>
        <form id="login-form" action='login.php' method="POST">
            <div class="form-group">
                <label>Email</label>
                <input type="text" class="form-control" id="login-email" name="email" placeholder="Email" required>
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" class="form-control" id="login-password" name="password" placeholder="Password" required>
            </div>
            <button type="submit" class="btn-submit" name="submit">Submit</button>
        </form>
        
        <a href="register.php">Don't have an account??Register Now</a>
    </div>


    <footer>
        <div class="social-media">
            <a href="#"><img src="facebook.png" alt="Facebook" height="50px" width="50px"></a>
            <a href="#"><img src="twitter.png" alt="X" height="50px" width="50px"></a>
            <a href="#"><img src="instagram.png" alt="Instagram" height="50px" width="50px"></a>
        </div>
        <div class="newsletter">
            <h3>Subscribe to Our Newsletter</h3>
            <form>
                <input type="email" placeholder="Enter your email">
                <button type="submit">Subscribe</button>
            </form>
        </div>
    </footer>
    <script src="animation.js">


    </script>
</body>

</html>

<?php
session_start();
session_destroy();
if(isset($_COOKIE['user'])) {
    setcookie('user', '', time() - 3600, '/');
}

if (isset($_POST["submit"])) {

    $con = mysqli_connect("localhost", "root", "aravind");
    mysqli_select_db($con, "groceryhub");

    $email = $_POST['email'];
    $password = $_POST['password'];

    $result = mysqli_query($con, "SELECT * FROM users WHERE email = '$email' and password = '$password'");
    $row = mysqli_fetch_array($result);
    
    if ($row) {
        setcookie("user", $row["name"], time() + 3600, "/");
        header("Location: main.php");
        exit();
    } else {
        echo "<script>alert('Invalid credentials')</script>";
        exit();
    }
    
}

?>


