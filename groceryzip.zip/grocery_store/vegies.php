<?php
session_start();
?>

<html>

<head>
    <title>EXOTIC FRUITS</title>
    <link rel="stylesheet" href="designn.css">

</head>

<body>
    <div class="top_body">
        <div class="top_part">
            <div class="top_left">
                <ul>
                    <li> <a href="main.php"><img src="logo.png" alt="grocey" width="70px" height="70px"></a></li>
                    <li><input type="text" placeholder="Search.."></li>
                </ul>
            </div>
            <div class="top_right">
                <ul>
                    <li><a href="login.php"><img src="login.png" alt="grocey" width="50px" height="50px"></a></li>
                    <li><a href="cart.php"><img src="shopping-basket.png" alt="grocey" width="50px" height="50px"></a></li>
                </ul>
            </div>
        </div>
        <div class="bottom_part">
            <ul>
                <li>Categoreies
                    <div class="dropdown">
                        <ul>
                            <li><a href="exotic_fruits.php">fruits</a></li>
                            <li><a href="vegies.php">vegies</a></li>
                            <li><a href="snacks.php">snacks</a></li>

                        </ul>
                    </div>
                </li>
                <li><a href="exotic_fruits.php">Exotic Fruits</a></li>
                <li><a href="dailyneeds.php">Daily Needs</a></li>
                <li><a href="vegies.php">Fresh Vegies</a></li>
                <li><a href="more.php">More About Us</a></li>
                <li><a href="contactus.php">Contact Us</a></li>
            </ul>


        </div>
    </div>
    <br>
    <h3 class="titleee">FRESH VEGETABLES</h3>
    <div class="vegies-container">
        <div class="vegies">
            <img src="potato.jpg" alt="vegies Name">
            <h4>Potato</h4>
            <p>50/kg</p>
            <div class="quantity">
            <form action="vegies.php" method="POST">
                    <input type="text" value="1" min="1" step="1" name="potatovalue">
                    <span>kg</span><br>
                    <button class="add-to-cart" name="potato">Add to Cart</button>
                </form>
                </div>
        </div>
        <div class="vegies">
            <img src="carrot.jpg" alt="vegies Name">
            <h4>Carrot</h4>
            <p>60/kg</p>
            <div class="quantity">
            <form action="vegies.php" method="POST">
                    <input type="text" value="1" min="1" step="1" name="carrotvalue">
                    <span>kg</span><br>
                    <button class="add-to-cart" name="carrot">Add to Cart</button>
                </form>
                </div>
        </div>
        <div class="vegies">
            <img src="onion.jpg" alt="vegies Name">
            <h4>Onion</h4>
            <p>45/kg</p>
            <div class="quantity">
            <form action="vegies.php" method="POST">
                    <input type="text" value="1" min="1" step="1" name="onionvalue">
                    <span>kg</span><br>
                    <button class="add-to-cart" name="onion">Add to Cart</button>
                </form>
                </div>
        </div>
        <div class="vegies">
            <img src="tomato.jpg" alt="vegies Name">
            <h4>Tomato</h4>
            <p>100/kg</p>
            <div class="quantity">
            <form action="vegies.php" method="POST">
                    <input type="text" value="1" min="1" step="1" name="tomatovalue">
                    <span>kg</span><br>
                    <button class="add-to-cart" name="tomato">Add to Cart</button>
                </form>
                </div>
        </div>
        <div class="vegies">
            <img src="broccoli.jpg" alt="vegies Name">
            <h4>Brocolli</h4>
            <p>25/pc</p>
            <div class="quantity">
            <form action="vegies.php" method="POST">
                    <input type="text" value="1" min="1" step="1" name="brocollivalue">
                    <span>pc</span><br>
                    <button class="add-to-cart" name="brocolli">Add to Cart</button>
                </form>
                </div>
        </div>
        <div class="vegies">
            <img src="eggplant.jpg" alt="vegies Name">
            <h4>EggPlant</h4>
            <p>76/kg</p>
            <div class="quantity">
            <form action="vegies.php" method="POST">
                    <input type="text" value="1" min="1" step="1" name="eggplantvalue">
                    <span>kg</span><br>
                    <button class="add-to-cart" name="eggplant">Add to Cart</button>
                </form>
                </div>
        </div>
        <div class="vegies">
            <img src="cabbage.jpg" alt="vegies Name">
            <h4>Cabbage</h4>
            <p>45/kg</p>
            <div class="quantity">
            <form action="vegies.php" method="POST">
                    <input type="text" value="1" min="1" step="1" name="cabbagevalue">
                    <span>kg</span><br>
                    <button class="add-to-cart" name="cabbage">Add to Cart</button>
                </form>
                </div>
        </div>
        <div class="vegies">
            <img src="cilantro.jpg" alt="vegies Name">
            <h4>Cilanto</h4>
            <p>15/bundle</p>
            <div class="quantity">
            <form action="vegies.php" method="POST">
                    <input type="text" value="1" min="1" step="1" name="cilantrovalue">
                    <span>bundle</span><br>
                    <button class="add-to-cart" name="cilantro">Add to Cart</button>
                </form>
                </div>
        </div>
    </div>



    <footer>
        <div class="social-media">
            <a href="#"><img src="facebook.png" alt="Facebook" height="50px" width="50px"></a>
            <a href="#"><img src="twitter.png" alt="X" height="50px" width="50px"></a>
            <a href="#"><img src="instagram.png" alt="Instagram" height="50px" width="50px"></a>
        </div>
        <div class="newsletter">
            <h3>Subscribe to Our Newsletter</h3>
            <form>
                <input type="email" placeholder="Enter your email">
                <button type="submit">Subscribe</button>
            </form>
        </div>
    </footer>
</body>

</html>


<?php


if (isset($_POST["potato"])) {
    $quantity = $_POST["potatovalue"];
    $_SESSION["cart"]["potato"] = array("quantity" => $quantity, "price" => 50);
}

if (isset($_POST["carrot"])) {
    $quantity = $_POST["carrotvalue"];
    $_SESSION["cart"]["carrot"] = array("quantity" => $quantity, "price" => 60);
}
if (isset($_POST["onion"])) {
    $quantity = $_POST["onionvalue"];
    $_SESSION["cart"]["onion"] = array("quantity" => $quantity, "price" => 45);
}

if (isset($_POST["tomato"])) {
    $quantity = $_POST["tomatovalue"];
    $_SESSION["cart"]["tomato"] = array("quantity" => $quantity, "price" => 100);
}
if (isset($_POST["brocolli"])) {
    $quantity = $_POST["brocollivalue"];
    $_SESSION["cart"]["brocolli"] = array("quantity" => $quantity, "price" => 25);
}
if (isset($_POST["eggplant"])) {
    $quantity = $_POST["eggplantvalue"];
    $_SESSION["cart"]["eggplant"] = array("quantity" => $quantity, "price" => 50);
}
if (isset($_POST["cabbage"])) {
    $quantity = $_POST["cabbagevalue"];
    $_SESSION["cart"]["cabbage"] = array("quantity" => $quantity, "price" => 45);
}
if (isset($_POST["cilantro"])) {
    $quantity = $_POST["cilantrovalue"];
    $_SESSION["cart"]["cilantro"] = array("quantity" => $quantity, "price" => 15);
}


?>