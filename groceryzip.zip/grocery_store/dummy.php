<?php

$user = $_COOKIE['user'];

echo $user;
